import os
from urllib.parse import quote_plus

import pandas as pd
from sqlalchemy import create_engine

# Password is read from an environment variable, never stored in the code
password = quote_plus(os.environ["MYSQL_PASSWORD"])

engine = create_engine(
    f'mysql+mysqlconnector://root:{password}@localhost/pricing_analysis'
)

pd.read_csv('03_clean_data/demand_clean.csv').to_sql('demand', engine, if_exists='replace', index=False)
pd.read_csv('03_clean_data/pricing_clean.csv').to_sql('pricing', engine, if_exists='replace', index=False)
pd.read_csv('03_clean_data/transactions_clean.csv').to_sql('transactions', engine, if_exists='replace', index=False)

print("All tables loaded successfully into MySQL!")