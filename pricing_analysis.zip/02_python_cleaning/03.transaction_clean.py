import pandas as pd
import numpy as np

df = pd.read_csv("raw_data/transactions.csv")

df.shape

df.info()

for col in df.columns:
    print("\n" + "="*50)
    print(f"COLUMN: {col}")
    print("="*50)

    print("\nTop 5 values:")
    print(df[col].head(5).to_string(index=False))

    print("\nUnique values:")
    print(df[col].unique())



print("\nNulls per column:\n", df.isna().sum())

print("\nExact duplicate rows:", df.duplicated().sum())



duplicate_ids = df[df["ride_id"].duplicated(keep=False)]

print(
    duplicate_ids
    .sort_values("ride_id")
    .head(50)
    .to_string(index=False)
)


before = len(df)
df = df.drop_duplicates()
print(f"\nDropped {before - len(df)} exact duplicate rows")
print(f"New row count: {len(df)}")


print("Unique ride IDs:", df["ride_id"].nunique())
print("Total rows:", len(df))


for col in ["platform", "city", "ride_type", "payment_mode", "ride_status", "promo_code"]:
    df[col] = df[col].astype("string").str.strip()

df["platform"] = df["platform"].str.title().replace({"Ola Cabs": "Ola"})

df["city"] = df["city"].str.title()
city_map = {
    "Bombay": "Mumbai", "Blr": "Bengaluru", "Bangalore": "Bengaluru",
    "New Delhi": "Delhi", "Delhi Ncr": "Delhi", "Calcutta": "Kolkata",
}
df["city"] = df["city"].replace(city_map)

df["ride_type"] = df["ride_type"].str.title().replace({"Prime Sedan": "Prime"})
df["payment_mode"] = df["payment_mode"].str.title()



categorical_cols = [
    "platform",
    "city",
    "ride_type",
    "payment_mode",
    "ride_status",
    "promo_code"
]

for col in categorical_cols:
    print(f"\n{col}:")
    print(df[col].unique())



df["date"] = pd.to_datetime(df["date"], errors="coerce")


numeric_cols = ["distance_km", "duration_min", "base_fare_inr", "surge_multiplier",
                 "discount_pct", "discount_amount_inr", "final_fare_inr"]
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")


df.info()

df.isnull().sum()


df["promo_code"] = df["promo_code"].fillna("No Promo")

df["discount_pct"] = df["discount_pct"].fillna(0)

df["discount_amount_inr"] = df["discount_amount_inr"].fillna(0)


df[df["ride_status"] == "Completed"]["final_fare_inr"].isnull().sum()

df["final_fare_inr"] = np.where(
    df["ride_status"] != "Completed",
    0,
    df["final_fare_inr"]
)




df["distance_km_imputed"] = df["distance_km"].isna().astype(int)

df["distance_km"] = df.groupby(
    ["city", "platform", "ride_type"]
)["distance_km"].transform(lambda x: x.fillna(x.median()))




df["duration_min_imputed"] = df["duration_min"].isna().astype(int)

df["duration_min"] = df.groupby(
    ["city", "platform", "ride_type"]
)["duration_min"].transform(lambda x: x.fillna(x.median()))




df["surge_multiplier_imputed"] = df["surge_multiplier"].isna().astype(int)

df["surge_multiplier"] = df.groupby(
    ["platform", "time_slot"]
)["surge_multiplier"].transform(lambda x: x.fillna(x.median()))



df["payment_mode"] = df["payment_mode"].fillna("Unknown")

df["distance_km"].describe()
df["duration_min"].describe()




Q1 = df["duration_min"].quantile(0.25)
Q3 = df["duration_min"].quantile(0.75)
IQR = Q3 - Q1
upper_bound = Q3 + 1.5 * IQR

df["duration_outlier_flag"] = (df["duration_min"] > upper_bound).astype(int)



print("\nNulls remaining:\n",df.isna().sum())

print("\nFinal shape:", df.shape)

df.to_csv("clean_data/transactions_clean.csv", index=False)