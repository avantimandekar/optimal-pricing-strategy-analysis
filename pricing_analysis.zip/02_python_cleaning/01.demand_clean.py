import pandas as pd
import numpy as np

df = pd.read_csv("01_raw_data/demand.csv")

df.shape

df.info()


for col in df.columns:
    print("\n" + "="*50)
    print(f"COLUMN: {col}")
    print("="*50)

    print("\nTop 5 values:")
    print(df[col].head(5).to_string(index=False))

    print("\nUnique values:")
    print(df[col].unique())



print("\nNulls per column:\n", df.isna().sum())

print("\nExact duplicate rows:", df.duplicated().sum())


before = len(df)
df = df.drop_duplicates()
print(f"Dropped {before - len(df)} exact duplicate rows")
print(f"New row count: {len(df)}")


for col in ["platform", "city", "ride_type", "time_slot"]:
    df[col] = df[col].astype("string").str.strip().str.title()

df["platform"] = df["platform"].replace({"Ola Cabs": "Ola"})
df["city"] = df["city"].replace({
    "Bombay": "Mumbai", "Blr": "Bengaluru", "Bangalore": "Bengaluru",
    "New Delhi": "Delhi", "Delhi Ncr": "Delhi", "Calcutta": "Kolkata",
})
df["ride_type"] = df["ride_type"].replace({"Prime Sedan": "Prime"})

df["date"] = pd.to_datetime(df["date"], errors="coerce")

for col in ["rides_requested", "rides_completed", "rides_cancelled"]:
    df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")


for col in ["total_revenue_inr", "total_distance_km", "total_discount_inr", "avg_surge_multiplier"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")


avg_price = (
    df["total_revenue_inr"] / df["rides_completed"].replace(0, np.nan)
).groupby(
    [df["platform"], df["ride_type"]]
).transform("median")
df["total_revenue_imputed"] = df["total_revenue_inr"].isna().astype(int)

df["total_revenue_inr"] = df["total_revenue_inr"].fillna(
    df["rides_completed"] * avg_price
)



avg_dist = df.groupby(["platform", "ride_type"])["total_distance_km"].transform(
    lambda x: (x / df.loc[x.index, "rides_requested"]).median()
)
df["total_distance_km_imputed"] = df["total_distance_km"].isna().astype(int)

df["total_distance_km"] = df["total_distance_km"].fillna(
    df["rides_requested"] * avg_dist
)



df["avg_surge_multiplier_imputed"] = (
    df["avg_surge_multiplier"].isna().astype(int)
)

df["avg_surge_multiplier"] = (
    df.groupby(["platform", "time_slot"])["avg_surge_multiplier"]
      .transform(lambda x: x.fillna(x.median()))
)



print("\nNulls remaining:\n", df.isna().sum())

print("Final shape:", df.shape)

df.to_csv("03_clean_data/demand_clean.csv", index=False)