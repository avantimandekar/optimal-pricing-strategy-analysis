import pandas as pd
import numpy as np

df = pd.read_csv("01_raw_data/pricing.csv")

df.shape

df.info()


for col in df.columns:
    print("\n" + "="*50)
    print(f"COLUMN: {col}")
    print("="*50)

    print("\nTop 5 values:")
    print(df[col].head(5).to_string(index=False))

    print("\nUnique values:")
    print(df[col].unique())



print("\nNulls per column:\n", df.isna().sum())

print("\nExact duplicate rows:", df.duplicated().sum())

before = len(df)
df = df.drop_duplicates()
print(f"Dropped {before - len(df)} exact duplicate rows")
print(f"New row count: {len(df)}")

for col in ["platform", "city", "ride_type"]:
    df[col] = df[col].astype("string").str.strip().str.title()

df["platform"] = df["platform"].replace({"Ola Cabs": "Ola"})

df["city"] = df["city"].replace({
    "Bombay": "Mumbai", "Blr": "Bengaluru", "Bangalore": "Bengaluru",
    "New Delhi": "Delhi", "Delhi Ncr": "Delhi", "Calcutta": "Kolkata",
})

df["ride_type"] = df["ride_type"].replace({"Prime Sedan": "Prime"})


categorical_cols = [
    "city",
    "platform",
    "ride_type"
]

for col in categorical_cols:
    print(f"\n{col}:")
    print(df[col].unique())


df["surge_active"] = df["surge_active"].astype("string")
df["surge_active"] = df["surge_active"].replace({
    "Y": "Yes",
    "N": "No"
})
df["surge_active"].unique()

df["promo_code"] = df["promo_code"].astype("string").str.strip().fillna("No Promo")
df["promo_code"].unique()


df["pricing_date"] = pd.to_datetime(df["pricing_date"], errors="coerce")


for col in ["base_fare_inr", "rate_per_km_inr", "rate_per_min_inr",
            "minimum_fare_inr", "surge_multiplier", "promo_discount_pct"]:

    df[col] = pd.to_numeric(df[col], errors="coerce")


df.info()


df["base_fare_imputed"] = df["base_fare_inr"].isna().astype(int)

df["base_fare_inr"] = (
    df.groupby(["platform", "city", "ride_type"])["base_fare_inr"]
      .transform(lambda x: x.fillna(x.median()))
)


df["rate_per_min_imputed"] = df["rate_per_min_inr"].isna().astype(int)

df["rate_per_min_inr"] = (
    df.groupby(["platform", "city", "ride_type"])["rate_per_min_inr"]
      .transform(lambda x: x.fillna(x.median()))
)


df["promo_discount_pct"] = df["promo_discount_pct"].fillna(0)

print("\nNulls remaining:\n", df.isna().sum())

print("Final shape:", df.shape)

df.to_csv("03_clean_data/pricing_clean.csv", index=False)