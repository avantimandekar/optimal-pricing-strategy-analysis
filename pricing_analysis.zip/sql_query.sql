CREATE DATABASE pricing_analysis;

SHOW DATABASES;

use pricing_analysis;


SELECT *
FROM transactions;

SELECT *
FROM pricing;

SELECT *
FROM demand;


#1. How do revenue and pricing differ across ride types across different platforms?
SELECT platform, ride_type,
       COUNT(*) AS rides_completed,
       ROUND(SUM(final_fare_inr), 0) AS total_revenue_inr,
       ROUND(AVG(final_fare_inr), 2) AS avg_fare_inr,
       ROUND(SUM(final_fare_inr) / SUM(distance_km), 2) AS price_per_km
FROM transactions
WHERE ride_status = 'Completed'
GROUP BY ride_type, platform
ORDER BY ride_type ASC, total_revenue_inr DESC;


#2. How does surge pricing affect ride completion rates and revenue across platforms?
SELECT
    CASE
        WHEN surge_multiplier <= 1.00 THEN '1. No surge'
        WHEN surge_multiplier <= 1.30 THEN '2. Low'
        WHEN surge_multiplier <= 1.60 THEN '3. Medium'
        ELSE '4. High'
    END AS surge_bucket,
    platform,
    COUNT(*) AS rides_requested,
    SUM(CASE WHEN ride_status = 'Completed' THEN 1 ELSE 0 END) AS rides_completed,
    ROUND(100.0 * SUM(CASE WHEN ride_status = 'Completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 2) AS completion_rate_pct,
    ROUND(SUM(CASE WHEN ride_status = 'Completed' THEN final_fare_inr ELSE 0 END), 0) AS revenue_inr,
    ROUND(AVG(CASE WHEN ride_status = 'Completed' THEN final_fare_inr END), 2) AS avg_fare_inr
FROM transactions

GROUP BY
    CASE
        WHEN surge_multiplier <= 1.00 THEN '1. No surge'
        WHEN surge_multiplier <= 1.30 THEN '2. Low'
        WHEN surge_multiplier <= 1.60 THEN '3. Medium'
        ELSE '4. High'
    END,
    platform
ORDER BY surge_bucket ASC, revenue_inr DESC;


#3. How much revenue comes from surged rides
SELECT
    CASE WHEN surge_multiplier = 1.00 THEN 'Non-Surge' ELSE 'Surge' END AS surge_status,
    COUNT(*) AS total_rides,
    ROUND(SUM(CASE WHEN ride_status = 'Completed' THEN final_fare_inr ELSE 0 END), 2) AS total_revenue_inr,
    ROUND(AVG(CASE WHEN ride_status = 'Completed' THEN final_fare_inr END), 2) AS avg_fare_inr
FROM transactions
GROUP BY
    CASE WHEN surge_multiplier = 1.00 THEN 'Non-Surge' ELSE 'Surge' 
    END
ORDER BY total_revenue_inr DESC;


#4. Which platform maximizes revenue across time slots?
SELECT
    time_slot,
    platform,
    COUNT(*) AS rides_requested,
    ROUND(AVG(surge_multiplier), 2) AS avg_surge,
    ROUND(SUM(CASE WHEN ride_status = 'Completed' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS completion_rate_pct,
    ROUND(SUM(CASE WHEN ride_status = 'Completed' THEN final_fare_inr ELSE 0 END), 0) AS revenue_inr
FROM transactions
GROUP BY time_slot, platform
ORDER BY time_slot ASC, revenue_inr DESC;


#5. How does price affect ride demand?
WITH demand_daily AS (
    SELECT
        STR_TO_DATE(`date`, '%Y-%m-%d') AS obs_date,
        city,
        platform,
        ride_type,
        SUM(rides_requested) AS rides_requested
    FROM demand
    GROUP BY
        STR_TO_DATE(`date`, '%Y-%m-%d'),
        city, platform, ride_type
),

matched_data AS (
    SELECT
        demand_daily.obs_date,
        demand_daily.city,
        demand_daily.platform,
        demand_daily.ride_type,
        demand_daily.rides_requested,
        pricing.minimum_fare_inr AS price
    FROM demand_daily 
    INNER JOIN pricing 
        ON demand_daily.obs_date = STR_TO_DATE(pricing.pricing_date, '%Y-%m-%d')
        AND demand_daily.city = pricing.city
        AND demand_daily.platform = pricing.platform
        AND demand_daily.ride_type = pricing.ride_type
    WHERE demand_daily.rides_requested > 0
      AND pricing.minimum_fare_inr > 0
),

logged_data AS (
    SELECT *,
        LN(price) AS log_price,
        LN(rides_requested) AS log_demand
    FROM matched_data
),

service_means AS (
    SELECT
        city, platform, ride_type,
        AVG(log_price) AS mean_log_price,
        AVG(log_demand) AS mean_log_demand
    FROM logged_data
    GROUP BY city, platform, ride_type
),

centered AS (
    SELECT
        logged_data.*,
        logged_data.log_price - service_means.mean_log_price AS x,
        logged_data.log_demand - service_means.mean_log_demand AS y
    FROM logged_data 
    JOIN service_means 
        ON logged_data.city = service_means.city
        AND logged_data.platform = service_means.platform
        AND logged_data.ride_type = service_means.ride_type
)

SELECT
    COUNT(*) AS observations,
    COUNT(DISTINCT city) AS cities,
    COUNT(DISTINCT platform) AS platforms,
    COUNT(DISTINCT ride_type) AS ride_types,
    MIN(obs_date) AS first_date,
    MAX(obs_date) AS last_date,
    ROUND(
        SUM(x * y) / NULLIF(SUM(x * x), 0),
        4
    ) AS preliminary_demand_elasticity
FROM centered;



#6. How does price sensitivity differ across platforms?
WITH demand_daily AS (
    SELECT
        STR_TO_DATE(`date`, '%Y-%m-%d') AS obs_date,
        city,
        platform,
        ride_type,
        SUM(rides_requested) AS rides_requested
    FROM demand
    GROUP BY
        STR_TO_DATE(`date`, '%Y-%m-%d'),
        city, platform, ride_type
),

matched_data AS (
    SELECT
        demand_daily.obs_date,
        demand_daily.city,
        demand_daily.platform,
        demand_daily.ride_type,
        demand_daily.rides_requested,
        pricing.minimum_fare_inr AS price
    FROM demand_daily 
    INNER JOIN pricing 
        ON demand_daily.obs_date = STR_TO_DATE(pricing.pricing_date, '%Y-%m-%d')
        AND demand_daily.city = pricing.city
        AND demand_daily.platform = pricing.platform
        AND demand_daily.ride_type = pricing.ride_type
    WHERE demand_daily.rides_requested > 0
      AND pricing.minimum_fare_inr > 0
),
logged_data AS (
    SELECT *,
        LN(price) AS log_price,
        LN(rides_requested) AS log_demand
    FROM matched_data
),
service_means AS (
    SELECT
        city, platform, ride_type,
        AVG(log_price) AS mean_log_price,
        AVG(log_demand) AS mean_log_demand
    FROM logged_data
    GROUP BY city, platform, ride_type
),
centered AS (
    SELECT
        logged_data.platform,
        logged_data.log_price - service_means.mean_log_price AS x,
        logged_data.log_demand - service_means.mean_log_demand AS y
    FROM logged_data
    JOIN service_means
        ON logged_data.city = service_means.city
        AND logged_data.platform = service_means.platform
        AND logged_data.ride_type = service_means.ride_type
)
SELECT
    platform,
    COUNT(*) AS observations,
    ROUND(
        SUM(x * y) / NULLIF(SUM(x * x), 0),
        4
    ) AS preliminary_elasticity
FROM centered
GROUP BY platform
ORDER BY platform;



#7. How do the platforms compare on transaction volume, ride completion rate, total revenue, average fare, and price per kilometer?
SELECT
    platform,
    COUNT(*) AS total_transactions,
    SUM(CASE WHEN ride_status = 'Completed' THEN 1 ELSE 0 END)
        AS rides_completed,
    ROUND(
        SUM(CASE WHEN ride_status = 'Completed' THEN 1 ELSE 0 END)
        * 100.0 / COUNT(*), 2
    ) AS completion_rate_pct,
    ROUND(SUM(CASE WHEN ride_status = 'Completed'
                   THEN final_fare_inr ELSE 0 END), 2)
        AS total_revenue_inr,
    ROUND(
        AVG(CASE WHEN ride_status = 'Completed'
                 THEN final_fare_inr END), 2
    ) AS avg_fare_inr,
    ROUND(
        SUM(CASE WHEN ride_status = 'Completed'
                 AND distance_km > 0
                 THEN final_fare_inr ELSE 0 END)
        / NULLIF(
            SUM(CASE WHEN ride_status = 'Completed'
                     AND distance_km > 0
                     THEN distance_km ELSE 0 END), 0
        ), 2
    ) AS price_per_km
FROM transactions
GROUP BY platform
ORDER BY total_revenue_inr DESC;


#8. What is each platform's price per km inside each ride type?
SELECT
    ride_type,
    ROUND(SUM(CASE WHEN platform = 'Uber'   THEN final_fare_inr END)
        / SUM(CASE WHEN platform = 'Uber'   THEN distance_km END), 2) AS Uber,
    ROUND(SUM(CASE WHEN platform = 'Ola'    THEN final_fare_inr END)
        / SUM(CASE WHEN platform = 'Ola'    THEN distance_km END), 2) AS Ola,
    ROUND(SUM(CASE WHEN platform = 'Rapido' THEN final_fare_inr END)
        / SUM(CASE WHEN platform = 'Rapido' THEN distance_km END), 2) AS Rapido
FROM transactions
WHERE ride_status = 'Completed'
  AND distance_km > 0
GROUP BY ride_type
ORDER BY ride_type;
   


#9. Which platform delivers the best balance of discount spend and ride completion?
SELECT
    platform,
    COUNT(*) AS total_rides,
    ROUND(AVG(discount_pct), 1) AS avg_discount_pct,
    ROUND(
        SUM(CASE WHEN ride_status = 'Completed' THEN 1 ELSE 0 END)
        * 100.0 / COUNT(*), 2
    ) AS completion_rate_pct,
    ROUND(
        SUM(CASE WHEN ride_status = 'Completed'
                 THEN discount_amount_inr ELSE 0 END), 2
    ) AS discount_cost_inr,
    ROUND(
        SUM(CASE WHEN ride_status = 'Completed'
                 THEN final_fare_inr ELSE 0 END), 2
    ) AS completed_revenue_inr
FROM transactions
GROUP BY platform
ORDER BY completion_rate_pct DESC;



#10. Why do rides fail on each platform?
WITH cancellation_rates AS (
    SELECT
        ride_status AS cancellation_reason,
        ROUND(
            100.0 * SUM(CASE WHEN platform = 'Uber' THEN 1 ELSE 0 END) /
            (SELECT COUNT(*) FROM transactions WHERE platform = 'Uber'), 2
        ) AS Uber,
        ROUND(
            100.0 * SUM(CASE WHEN platform = 'Ola' THEN 1 ELSE 0 END) /
            (SELECT COUNT(*) FROM transactions WHERE platform = 'Ola'), 2
        ) AS Ola,
        ROUND(
            100.0 * SUM(CASE WHEN platform = 'Rapido' THEN 1 ELSE 0 END) /
            (SELECT COUNT(*) FROM transactions WHERE platform = 'Rapido'), 2
        ) AS Rapido,
        ROUND(
            COUNT(*) * 100.0 / (SELECT COUNT(*) FROM transactions), 2
        ) AS overall_cancellation_rate_pct
    FROM transactions
    WHERE ride_status IN (
        'Cancelled by Customer',
        'Cancelled by Driver',
        'No Driver Found'
    )
    GROUP BY ride_status
)
SELECT *
FROM cancellation_rates
ORDER BY overall_cancellation_rate_pct DESC;



 #11. Does the same pattern hold inside each ride type?
SELECT ride_type,
       CASE WHEN surge_multiplier <= 1.3 THEN 'Low/No surge' ELSE 'High surge' END AS surge_band,
       COUNT(*) AS rides_requested,
       ROUND(SUM(CASE WHEN ride_status = 'Completed' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS completion_rate_pct
FROM transactions
GROUP BY ride_type, surge_band
ORDER BY ride_type, surge_band;


#12. Uber: does promo depth pay off? (completion rate, discount cost and revenue by promo)
SELECT
    promo_code,
    COUNT(*) AS rides_requested,
    ROUND(SUM(CASE WHEN ride_status = 'Completed' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS completion_rate_pct,
    ROUND(AVG(CASE WHEN ride_status = 'Completed' THEN discount_pct END), 1) AS avg_discount_pct_on_completed,
    ROUND(SUM(CASE WHEN ride_status = 'Completed' THEN discount_amount_inr ELSE 0 END), 0) AS discount_cost_inr,
    ROUND(SUM(CASE WHEN ride_status = 'Completed' THEN final_fare_inr ELSE 0 END), 0) AS revenue_inr
FROM transactions
WHERE platform = 'Uber'
GROUP BY promo_code
ORDER BY avg_discount_pct_on_completed;


#13. Uber: revenue share by time slot (where is the money earned?)
SELECT
    time_slot,
    COUNT(*) AS rides_completed,
    ROUND(SUM(final_fare_inr), 0) AS revenue_inr,
    ROUND(100.0 * SUM(final_fare_inr) / SUM(SUM(final_fare_inr)) OVER (), 1) AS revenue_share_pct
FROM transactions
WHERE platform = 'Uber' AND ride_status = 'Completed'
GROUP BY time_slot
ORDER BY revenue_inr DESC;


#14. Uber: ride-type mix, share of rides vs share of revenue
SELECT
    ride_type,
    COUNT(*) AS rides_completed,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS ride_share_pct,
    ROUND(SUM(final_fare_inr), 0) AS revenue_inr,
    ROUND(100.0 * SUM(final_fare_inr) / SUM(SUM(final_fare_inr)) OVER (), 1) AS revenue_share_pct,
    ROUND(AVG(final_fare_inr), 2) AS avg_fare_inr
FROM transactions
WHERE platform = 'Uber' AND ride_status = 'Completed'
GROUP BY ride_type
ORDER BY revenue_inr DESC;
